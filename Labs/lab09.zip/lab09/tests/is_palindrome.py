test = {
  'name': 'is_palindrome',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': '283f29564937de236873fd9ad423ca2b',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The is_palindrome function runs in ____ time in the length of its input.'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
